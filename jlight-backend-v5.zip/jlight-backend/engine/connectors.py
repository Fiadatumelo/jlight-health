"""
JLIGHT v4 — System Connectors
================================
Real-time data connectors for:
  1. NGS LIMS REST API (Genomics laboratories · Open-source)
  2. HL7 v2.5 listener (Laboratory information systems · 265+ SA labs)
  3. Clinical trial data system REST API (Academic institutions · CROs)
  4. CSV pipeline (any system - universal fallback)
  5. FHIR R4 adapter (Modern hospital information systems)

Each connector:
  - Pulls data from the source system
  - Normalises it to JLIGHT's internal format
  - Feeds the ML pipeline
  - Returns a structured DataFeed object

Author: JLIGHT · Team Fiada Mothapo · Hackathon 2026
"""

import json
import socket
import threading
import re
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any
from urllib.request import urlopen, Request
from urllib.parse import urlencode, quote
from urllib.error import URLError, HTTPError


# ─── Shared Data Structures ──────────────────────────────────────────────────

@dataclass
class DataPoint:
    """Single normalised data point from any source system."""
    timestamp: str
    value: float
    field_name: str
    source_system: str
    record_id: str = ""
    batch_id: str = ""
    instrument_id: str = ""
    unit: str = ""
    flag: str = ""
    raw: Dict = field(default_factory=dict)

@dataclass
class DataFeed:
    """Normalised feed from a connector — ready for ML pipeline."""
    source: str           # islims / hl7 / redcap / csv / fhir
    record_count: int
    field_name: str       # primary field analysed (cv_pct, result, etc)
    values: List[float]
    timestamps: List[str]
    data_points: List[DataPoint]
    metadata: Dict = field(default_factory=dict)
    connected: bool = True
    error: Optional[str] = None

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["data_points"] = [asdict(p) for p in self.data_points]
        return d


# ─── 1. iSkyLIMS REST Connector ──────────────────────────────────────────────

class iSkyLIMSConnector:
    """
    Connects to iSkyLIMS via REST API.
    iSkyLIMS is open-source NGS LIMS used by National Genomics Network and SA genomics labs.
    GitHub: https://github.com/BU-ISCIII/iSkyLIMS

    Endpoints used:
      GET /wetlab/api/runStats/       — NGS run statistics
      GET /wetlab/api/sampleSheet/    — Sample sheet data
      GET /drylab/api/serviceList/    — Bioinformatics services
    """

    def __init__(self, base_url: str, token: str = "", timeout: int = 10):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self.headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        if token:
            self.headers["Authorization"] = f"Token {token}"

    def _get(self, endpoint: str, params: Dict = None) -> Dict:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        if params:
            url += "?" + urlencode(params)
        req = Request(url, headers=self.headers)
        try:
            with urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except HTTPError as e:
            raise ConnectionError(f"iSkyLIMS HTTP {e.code}: {e.reason}")
        except URLError as e:
            raise ConnectionError(f"iSkyLIMS connection failed: {e.reason}")

    def get_run_stats(self, run_id: str = None) -> DataFeed:
        """Fetch NGS run QC statistics."""
        try:
            params = {}
            if run_id:
                params["runName"] = run_id

            data = self._get("/wetlab/api/runStats/", params)
            runs = data if isinstance(data, list) else data.get("results", [data])

            points = []
            values = []
            timestamps = []

            for run in runs:
                # Extract Q30, GC content, duplication from run stats
                for metric_key, field_name in [
                    ("q30", "q30_pct"),
                    ("gcContent", "gc_pct"),
                    ("duplication", "dup_pct"),
                    ("totalReads", "total_reads"),
                ]:
                    val = run.get(metric_key) or run.get("stats", {}).get(metric_key)
                    if val is not None:
                        try:
                            fval = float(str(val).replace("%", ""))
                            ts = run.get("runDate") or run.get("date") or datetime.now(timezone.utc).isoformat()
                            points.append(DataPoint(
                                timestamp=str(ts),
                                value=fval,
                                field_name=field_name,
                                source_system="iSkyLIMS",
                                record_id=str(run.get("runName", run.get("id", ""))),
                                raw=run,
                            ))
                            if field_name == "q30_pct":
                                values.append(fval)
                                timestamps.append(str(ts))
                        except (ValueError, TypeError):
                            pass

            return DataFeed(
                source="islims",
                record_count=len(runs),
                field_name="q30_pct",
                values=values,
                timestamps=timestamps,
                data_points=points,
                metadata={"run_id": run_id, "endpoint": "runStats"},
            )

        except Exception as e:
            return DataFeed(
                source="islims", record_count=0,
                field_name="q30_pct", values=[], timestamps=[],
                data_points=[], connected=False, error=str(e)
            )

    def get_sample_sheet(self, run_id: str) -> DataFeed:
        """Fetch sample sheet for a specific run."""
        try:
            data = self._get(f"/wetlab/api/sampleSheet/{quote(run_id)}/")
            samples = data if isinstance(data, list) else [data]
            points = []
            for s in samples:
                points.append(DataPoint(
                    timestamp=datetime.now(timezone.utc).isoformat(),
                    value=float(s.get("concentration", 0) or 0),
                    field_name="concentration",
                    source_system="iSkyLIMS",
                    record_id=str(s.get("sampleName", "")),
                    raw=s,
                ))
            return DataFeed(
                source="islims", record_count=len(samples),
                field_name="concentration",
                values=[p.value for p in points],
                timestamps=[p.timestamp for p in points],
                data_points=points,
                metadata={"run_id": run_id},
            )
        except Exception as e:
            return DataFeed(
                source="islims", record_count=0,
                field_name="concentration", values=[], timestamps=[],
                data_points=[], connected=False, error=str(e)
            )

    def test_connection(self) -> bool:
        try:
            self._get("/wetlab/api/runStats/", {"limit": 1})
            return True
        except Exception:
            return False


# ─── 2. HL7 v2.5 Listener ────────────────────────────────────────────────────

class HL7Parser:
    """
    Parse HL7 v2.5 messages from LIMS/HIS systems.
    Handles: OBR (observation request), OBX (observation result),
             MSH (message header), PID (patient), NTE (notes)

    Used by: Laboratory Information System (National Lab Network), SCC SoftLab, most SA hospital systems.
    """

    SEGMENT_SEP = "\r"
    FIELD_SEP = "|"
    COMPONENT_SEP = "^"
    REPEAT_SEP = "~"

    def parse(self, raw_message: str) -> Dict:
        """Parse a raw HL7 v2.5 message into a structured dict."""
        message = raw_message.replace("\r\n", "\r").replace("\n", "\r")
        segments = [s for s in message.split(self.SEGMENT_SEP) if s.strip()]
        result = {"segments": {}, "observations": [], "raw": raw_message}

        for seg in segments:
            fields = seg.split(self.FIELD_SEP)
            seg_type = fields[0]

            if seg_type == "MSH":
                result["segments"]["MSH"] = {
                    "sending_app": self._get_field(fields, 2),
                    "sending_facility": self._get_field(fields, 3),
                    "message_type": self._get_field(fields, 8),
                    "message_id": self._get_field(fields, 9),
                    "timestamp": self._get_field(fields, 6),
                }

            elif seg_type == "PID":
                result["segments"]["PID"] = {
                    "patient_id": self._get_field(fields, 3),
                    "patient_name": self._get_field(fields, 5),
                    "dob": self._get_field(fields, 7),
                    "sex": self._get_field(fields, 8),
                }

            elif seg_type == "OBR":
                result["segments"]["OBR"] = {
                    "order_id": self._get_field(fields, 2),
                    "universal_service_id": self._get_field(fields, 4),
                    "observation_datetime": self._get_field(fields, 7),
                    "collector_id": self._get_field(fields, 10),
                    "specimen_source": self._get_field(fields, 15),
                    "ordering_provider": self._get_field(fields, 16),
                }

            elif seg_type == "OBX":
                # Observation result — this is the key QC/result data
                obs = {
                    "set_id": self._get_field(fields, 1),
                    "value_type": self._get_field(fields, 2),
                    "observation_id": self._get_field(fields, 3),
                    "observation_name": self._get_field(fields, 3).split("^")[1] if "^" in self._get_field(fields, 3) else self._get_field(fields, 3),
                    "value": self._get_field(fields, 5),
                    "units": self._get_field(fields, 6),
                    "reference_range": self._get_field(fields, 7),
                    "abnormal_flags": self._get_field(fields, 8),
                    "observation_status": self._get_field(fields, 11),
                    "observation_datetime": self._get_field(fields, 14),
                }
                # Try to parse numeric value
                try:
                    obs["numeric_value"] = float(obs["value"])
                except (ValueError, TypeError):
                    obs["numeric_value"] = None
                result["observations"].append(obs)

        return result

    def _get_field(self, fields: List[str], index: int) -> str:
        try:
            return fields[index].strip() if index < len(fields) else ""
        except IndexError:
            return ""

    def extract_qc_values(self, parsed: Dict) -> List[DataPoint]:
        """Extract QC-relevant values from a parsed HL7 message."""
        points = []
        msh = parsed.get("segments", {}).get("MSH", {})
        obr = parsed.get("segments", {}).get("OBR", {})

        for obs in parsed.get("observations", []):
            val = obs.get("numeric_value")
            if val is None:
                continue

            # Identify QC-relevant observation types
            obs_id = obs.get("observation_id", "").upper()
            obs_name = obs.get("observation_name", "").lower()

            field_name = "result"
            if any(kw in obs_name for kw in ["cv", "coefficient", "variability"]):
                field_name = "cv_pct"
            elif any(kw in obs_name for kw in ["mean", "average"]):
                field_name = "mean"
            elif any(kw in obs_name for kw in ["sd", "standard dev"]):
                field_name = "sd"

            ts = obs.get("observation_datetime") or obr.get("observation_datetime") or msh.get("timestamp") or datetime.now(timezone.utc).isoformat()

            points.append(DataPoint(
                timestamp=str(ts),
                value=float(val),
                field_name=field_name,
                source_system=msh.get("sending_facility", "HL7_Source"),
                record_id=obr.get("order_id", ""),
                instrument_id=msh.get("sending_app", ""),
                unit=obs.get("units", ""),
                flag=obs.get("abnormal_flags", ""),
                raw=obs,
            ))

        return points


class HL7Listener:
    """
    TCP socket listener for incoming HL7 v2.5 MLLP messages.
    MLLP = Minimal Lower Layer Protocol — standard for HL7 over TCP.

    Used by: Laboratory Information System → JLIGHT real-time feed
    Port: 2575 (standard HL7 MLLP port)
    """

    MLLP_START = b"\x0b"   # VT character
    MLLP_END = b"\x1c\x0d" # FS + CR

    def __init__(self, host: str = "0.0.0.0", port: int = 2575, callback=None):
        self.host = host
        self.port = port
        self.callback = callback  # Called with each parsed message
        self.parser = HL7Parser()
        self.running = False
        self._thread = None
        self.messages_received = 0
        self.last_error = None

    def start(self):
        """Start listening for HL7 messages in a background thread."""
        self.running = True
        self._thread = threading.Thread(target=self._listen, daemon=True)
        self._thread.start()

    def stop(self):
        self.running = False

    def _listen(self):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
                srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                srv.bind((self.host, self.port))
                srv.listen(5)
                srv.settimeout(1.0)
                while self.running:
                    try:
                        conn, addr = srv.accept()
                        threading.Thread(
                            target=self._handle_connection,
                            args=(conn, addr),
                            daemon=True
                        ).start()
                    except socket.timeout:
                        continue
        except Exception as e:
            self.last_error = str(e)
            self.running = False

    def _handle_connection(self, conn, addr):
        try:
            with conn:
                data = b""
                while True:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                    if self.MLLP_END in data:
                        break

                # Strip MLLP framing
                raw = data
                if self.MLLP_START in raw:
                    raw = raw[raw.index(self.MLLP_START) + 1:]
                if self.MLLP_END in raw:
                    raw = raw[:raw.index(self.MLLP_END)]

                message_text = raw.decode("utf-8", errors="ignore")
                parsed = self.parser.parse(message_text)
                self.messages_received += 1

                # Send ACK
                ack = self._build_ack(parsed)
                conn.send(self.MLLP_START + ack.encode() + self.MLLP_END)

                # Trigger callback
                if self.callback:
                    self.callback(parsed)

        except Exception as e:
            self.last_error = str(e)

    def _build_ack(self, parsed: Dict) -> str:
        """Build HL7 ACK response."""
        msh = parsed.get("segments", {}).get("MSH", {})
        now = datetime.now().strftime("%Y%m%d%H%M%S")
        msg_id = msh.get("message_id", "UNKNOWN")
        return (
            f"MSH|^~\\&|JLIGHT|JLIGHT|{msh.get('sending_app','')}|"
            f"{msh.get('sending_facility','')}|{now}||ACK|{now}|P|2.5\r"
            f"MSA|AA|{msg_id}|Message accepted by JLIGHT\r"
        )

    def parse_message(self, raw_hl7: str) -> DataFeed:
        """Parse a single HL7 message string and return a DataFeed."""
        parsed = self.parser.parse(raw_hl7)
        points = self.parser.extract_qc_values(parsed)
        cv_points = [p for p in points if p.field_name == "cv_pct"]
        primary = cv_points if cv_points else points

        return DataFeed(
            source="hl7",
            record_count=len(parsed.get("observations", [])),
            field_name=primary[0].field_name if primary else "result",
            values=[p.value for p in primary],
            timestamps=[p.timestamp for p in primary],
            data_points=points,
            metadata={
                "sending_facility": parsed.get("segments", {}).get("MSH", {}).get("sending_facility", ""),
                "message_type": parsed.get("segments", {}).get("MSH", {}).get("message_type", ""),
                "observations": len(parsed.get("observations", [])),
            },
        )


# ─── 3. REDCap REST Connector ─────────────────────────────────────────────────

class REDCapConnector:
    """
    Connects to REDCap via REST API.
    REDClinical trial data systems are used across academic institutions and most SA clinical trial sites.
    
    Pulls:
      - Consent records → detect timing violations
      - Adverse events → flag SAE reporting deadlines  
      - Protocol deviations → pattern detection
      - Enrollment data → recruitment anomaly detection
    """

    def __init__(self, url: str, token: str, timeout: int = 15):
        self.url = url.rstrip("/") + "/api/"
        self.token = token
        self.timeout = timeout

    def _post(self, data: Dict) -> Any:
        data["token"] = self.token
        data["format"] = "json"
        data["returnFormat"] = "json"
        encoded = urlencode(data).encode("utf-8")
        req = Request(
            self.url,
            data=encoded,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        try:
            with urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except HTTPError as e:
            raise ConnectionError(f"REDCap HTTP {e.code}: {e.reason}")
        except URLError as e:
            raise ConnectionError(f"REDCap connection failed: {e.reason}")

    def get_records(self, fields: List[str] = None, forms: List[str] = None) -> DataFeed:
        """Fetch records from REDCap project."""
        try:
            params = {"content": "record", "type": "flat"}
            if fields:
                params["fields"] = ",".join(fields)
            if forms:
                params["forms"] = ",".join(forms)

            records = self._post(params)
            if not isinstance(records, list):
                records = [records]

            points = []
            consent_times = []
            procedure_times = []

            for rec in records:
                rec_id = str(rec.get("record_id", rec.get("id", "")))

                # Check consent timing
                consent_dt = rec.get("consent_date") or rec.get("ic_date")
                procedure_dt = rec.get("procedure_date") or rec.get("first_procedure_date")

                if consent_dt and procedure_dt:
                    try:
                        # Calculate hours between consent and first procedure
                        from datetime import datetime as dt
                        c = dt.fromisoformat(str(consent_dt).replace("Z", "+00:00"))
                        p = dt.fromisoformat(str(procedure_dt).replace("Z", "+00:00"))
                        hours_diff = abs((p - c).total_seconds() / 3600)

                        # Flag if < 24 hours (GCP requirement)
                        flag = "VIOLATION" if hours_diff < 24 else "OK"
                        points.append(DataPoint(
                            timestamp=str(consent_dt),
                            value=hours_diff,
                            field_name="consent_to_procedure_hours",
                            source_system="REDCap",
                            record_id=rec_id,
                            flag=flag,
                            raw=rec,
                        ))
                        consent_times.append(hours_diff)
                    except (ValueError, TypeError):
                        pass

                # Check SAE records
                sae_date = rec.get("sae_date") or rec.get("adverse_event_date")
                if sae_date:
                    try:
                        from datetime import datetime as dt
                        sae_dt = dt.fromisoformat(str(sae_date).replace("Z", "+00:00"))
                        days_since = (dt.now() - sae_dt.replace(tzinfo=None)).days
                        # SAE must be reported within 7 days
                        flag = "OVERDUE" if days_since > 7 else "PENDING" if days_since > 5 else "OK"
                        points.append(DataPoint(
                            timestamp=str(sae_date),
                            value=float(days_since),
                            field_name="sae_days_since_event",
                            source_system="REDCap",
                            record_id=rec_id,
                            flag=flag,
                            raw=rec,
                        ))
                    except (ValueError, TypeError):
                        pass

            # Primary series: consent timing violations
            primary_values = consent_times if consent_times else [float(i) for i in range(len(records))]
            primary_ts = [p.timestamp for p in points[:len(primary_values)]]

            return DataFeed(
                source="redcap",
                record_count=len(records),
                field_name="consent_to_procedure_hours",
                values=primary_values,
                timestamps=primary_ts,
                data_points=points,
                metadata={
                    "total_records": len(records),
                    "consent_violations": sum(1 for p in points if p.flag == "VIOLATION"),
                    "sae_overdue": sum(1 for p in points if p.flag == "OVERDUE"),
                },
            )

        except Exception as e:
            return DataFeed(
                source="redcap", record_count=0,
                field_name="consent_to_procedure_hours",
                values=[], timestamps=[],
                data_points=[], connected=False, error=str(e)
            )

    def get_project_info(self) -> Dict:
        """Get project metadata."""
        try:
            return self._post({"content": "project"})
        except Exception as e:
            return {"error": str(e)}

    def test_connection(self) -> bool:
        try:
            info = self.get_project_info()
            return "error" not in info
        except Exception:
            return False


# ─── 4. FHIR R4 Adapter ──────────────────────────────────────────────────────

class FHIRAdapter:
    """
    FHIR R4 REST adapter for modern health systems.
    Compatible with: Hospital Information System, Electronic Health Record System, any SMART-on-FHIR server.
    
    Resources used:
      - Observation     — lab results, QC values, vitals
      - DiagnosticReport — lab reports
      - Patient         — demographics
      - Encounter       — bed occupancy, admissions
    """

    def __init__(self, base_url: str, token: str = "", timeout: int = 15):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def _get(self, resource: str, params: Dict = None) -> Dict:
        url = f"{self.base_url}/{resource}"
        if params:
            url += "?" + urlencode(params)
        headers = {
            "Accept": "application/fhir+json",
            "Content-Type": "application/fhir+json",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        req = Request(url, headers=headers)
        try:
            with urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except HTTPError as e:
            raise ConnectionError(f"FHIR HTTP {e.code}: {e.reason}")
        except URLError as e:
            raise ConnectionError(f"FHIR connection failed: {e.reason}")

    def get_observations(self, code: str = None, patient_id: str = None, count: int = 100) -> DataFeed:
        """Fetch Observation resources (lab results, QC values)."""
        try:
            params = {"_count": count, "_sort": "-date"}
            if code:
                params["code"] = code
            if patient_id:
                params["patient"] = patient_id

            bundle = self._get("Observation", params)
            entries = bundle.get("entry", [])
            points = []
            values = []
            timestamps = []

            for entry in entries:
                obs = entry.get("resource", {})
                if obs.get("resourceType") != "Observation":
                    continue

                # Extract value
                val = None
                field_name = "result"
                if "valueQuantity" in obs:
                    val = obs["valueQuantity"].get("value")
                    field_name = obs["valueQuantity"].get("code", "result")
                elif "valueString" in obs:
                    try:
                        val = float(obs["valueString"])
                    except (ValueError, TypeError):
                        pass

                if val is None:
                    continue

                ts = obs.get("effectiveDateTime") or obs.get("issued") or datetime.now(timezone.utc).isoformat()
                rec_id = obs.get("id", "")

                # Get LOINC code name
                coding = obs.get("code", {}).get("coding", [{}])[0]
                obs_name = coding.get("display", field_name)

                if any(kw in obs_name.lower() for kw in ["cv", "coefficient"]):
                    field_name = "cv_pct"
                elif any(kw in obs_name.lower() for kw in ["hemoglobin", "haemoglobin", "hb"]):
                    field_name = "hemoglobin"

                points.append(DataPoint(
                    timestamp=str(ts),
                    value=float(val),
                    field_name=field_name,
                    source_system="FHIR_R4",
                    record_id=rec_id,
                    unit=obs.get("valueQuantity", {}).get("unit", ""),
                    flag="H" if obs.get("interpretation", [{}])[0].get("coding", [{}])[0].get("code") == "H" else "",
                    raw=obs,
                ))
                values.append(float(val))
                timestamps.append(str(ts))

            return DataFeed(
                source="fhir",
                record_count=len(entries),
                field_name=points[0].field_name if points else "result",
                values=values,
                timestamps=timestamps,
                data_points=points,
                metadata={
                    "total": bundle.get("total", len(entries)),
                    "code": code,
                    "fhir_version": "R4",
                },
            )

        except Exception as e:
            return DataFeed(
                source="fhir", record_count=0,
                field_name="result", values=[], timestamps=[],
                data_points=[], connected=False, error=str(e)
            )

    def get_bed_occupancy(self) -> DataFeed:
        """Fetch bed occupancy from Encounter resources."""
        try:
            params = {"status": "in-progress", "_count": 500}
            bundle = self._get("Encounter", params)
            entries = bundle.get("entry", [])

            # Count by ward/location
            ward_counts = {}
            for entry in entries:
                enc = entry.get("resource", {})
                locations = enc.get("location", [])
                for loc in locations:
                    ward = loc.get("location", {}).get("display", "Unknown")
                    ward_counts[ward] = ward_counts.get(ward, 0) + 1

            points = []
            for ward, count in ward_counts.items():
                points.append(DataPoint(
                    timestamp=datetime.now(timezone.utc).isoformat(),
                    value=float(count),
                    field_name="bed_occupancy",
                    source_system="FHIR_R4",
                    record_id=ward,
                    raw={"ward": ward, "count": count},
                ))

            return DataFeed(
                source="fhir",
                record_count=len(entries),
                field_name="bed_occupancy",
                values=[p.value for p in points],
                timestamps=[p.timestamp for p in points],
                data_points=points,
                metadata={"ward_breakdown": ward_counts},
            )
        except Exception as e:
            return DataFeed(
                source="fhir", record_count=0,
                field_name="bed_occupancy", values=[], timestamps=[],
                data_points=[], connected=False, error=str(e)
            )

    def test_connection(self) -> bool:
        try:
            meta = self._get("metadata")
            return meta.get("resourceType") == "CapabilityStatement"
        except Exception:
            return False


# ─── 5. Universal CSV Pipeline ───────────────────────────────────────────────

class CSVPipeline:
    """
    Universal CSV ingestion — works with ANY system that can export CSV.
    This is the fallback for systems without API/HL7 support.
    
    Used by: TIER.Net (TB/HIV), paper-based trial sites, any LIMS export.
    """

    def ingest(self, csv_text: str, source_name: str = "CSV") -> DataFeed:
        """Parse CSV text and return a DataFeed."""
        from engine.csv_engine import CSVParser, detect_column, extract_numeric_series, CV_KEYWORDS, MEAN_KEYWORDS, TIME_KEYWORDS
        import io
        import pandas as pd

        parser = CSVParser()
        try:
            content = csv_text.encode("utf-8")
            df, meta = parser.parse(content, f"{source_name}.csv")

            cv_col = detect_column(df, CV_KEYWORDS)
            mean_col = detect_column(df, MEAN_KEYWORDS)
            time_col = detect_column(df, TIME_KEYWORDS)
            primary_col = cv_col or mean_col

            if not primary_col:
                for col in df.columns:
                    series = extract_numeric_series(df, col)
                    if len(series) >= 3:
                        primary_col = col
                        break

            if not primary_col:
                return DataFeed(
                    source="csv", record_count=0, field_name="unknown",
                    values=[], timestamps=[], data_points=[],
                    connected=False, error="No numeric columns found"
                )

            values = extract_numeric_series(df, primary_col)
            timestamps = df[time_col].astype(str).tolist() if time_col else [str(i) for i in range(len(values))]

            points = [
                DataPoint(
                    timestamp=timestamps[i] if i < len(timestamps) else str(i),
                    value=v,
                    field_name=primary_col,
                    source_system=source_name,
                    record_id=str(i),
                    raw={},
                )
                for i, v in enumerate(values)
            ]

            return DataFeed(
                source="csv",
                record_count=meta["row_count"],
                field_name=primary_col,
                values=values,
                timestamps=timestamps[:len(values)],
                data_points=points,
                metadata=meta,
            )

        except Exception as e:
            return DataFeed(
                source="csv", record_count=0, field_name="unknown",
                values=[], timestamps=[], data_points=[],
                connected=False, error=str(e)
            )


# ─── Connector Factory ────────────────────────────────────────────────────────

def get_connector(source: str, config: Dict):
    """
    Factory function — returns the right connector for a given source.
    
    Usage:
        connector = get_connector("islims", {"url": "...", "token": "..."})
        feed = connector.get_run_stats()
        ml_result = pipeline.run(feed.values, feed.timestamps)
    """
    source = source.lower()
    if source in ("islims", "iskylims", "skylims"):
        return iSkyLIMSConnector(
            base_url=config.get("url", ""),
            token=config.get("token", ""),
            timeout=config.get("timeout", 10),
        )
    elif source in ("hl7", "trakcare", "nhls", "scc"):
        return HL7Listener(
            host=config.get("host", "0.0.0.0"),
            port=int(config.get("port", 2575)),
            callback=config.get("callback"),
        )
    elif source in ("redcap", "clinical_trial", "ctms"):
        return REDCapConnector(
            url=config.get("url", ""),
            token=config.get("token", ""),
            timeout=config.get("timeout", 15),
        )
    elif source in ("fhir", "fhir_r4", "meditech", "epic"):
        return FHIRAdapter(
            base_url=config.get("url", ""),
            token=config.get("token", ""),
            timeout=config.get("timeout", 15),
        )
    elif source in ("csv", "tier", "tiernetwork", "csv_pipeline"):
        return CSVPipeline()
    else:
        raise ValueError(f"Unknown connector source: {source}. Valid: islims, hl7, redcap, fhir, csv")
