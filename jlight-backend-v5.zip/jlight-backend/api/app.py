"""
JLIGHT v4 — Flask REST API
=============================
Endpoints:
  POST /api/analyse-csv       — CSV/XLSX QC analysis
  POST /api/bio/tb            — TB drug resistance screening
  POST /api/bio/variant       — Variant analysis
  POST /api/bio/ngs           — NGS QC metrics
  POST /api/bio/wgs           — WGS assembly metrics
  POST /api/bio/sequence      — Sequence analysis
  POST /api/bio/fasta         — Parse FASTA/FASTQ file
  GET  /api/health            — System health check
  GET  /api/cards             — Decision cards (from DB or static)
  POST /api/cards/acknowledge — Acknowledge a card
  GET  /api/audit             — Audit log

Author: JLIGHT · Team Fiada Mothapo · Hackathon 2026
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import os
import json
import traceback
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, request, jsonify, g
from flask_cors import CORS

from engine.csv_engine import analyse_csv
from engine.bio_engine import (
    screen_tb_resistance,
    detect_variants,
    analyse_ngs_quality,
    calculate_wgs_metrics,
    analyse_sequence,
    parse_fasta,
)

# ─── App Setup ───────────────────────────────────────────────────────────────

app = Flask(__name__)
# Restrict CORS to known JLIGHT origins only
ALLOWED_ORIGINS = [
    "https://jlight-health.co.za",
    "https://www.jlight-health.co.za",
    "http://localhost:3000",
    "http://127.0.0.1:5500",
    "http://localhost:5500",
    # Add your Netlify preview URLs here
]
CORS(app, origins=ALLOWED_ORIGINS, supports_credentials=False)

# ════════════════════════════════════════════════════════════
# JLIGHT SECURITY MIDDLEWARE — Enterprise Grade
# Defense: DDoS, replay attacks, injection, scanner blocking
# ════════════════════════════════════════════════════════════
from collections import defaultdict
import time as _time
import re as _re

# ── Tiered Rate Limiting ──────────────────────────────────
_request_counts = defaultdict(list)
_blocked_ips = {}
_RATE_LIMIT = 100
_BURST_LIMIT = 20
_BLOCK_DURATION = 300

def check_rate_limit(ip):
    now = _time.time()
    if ip in _blocked_ips:
        if now < _blocked_ips[ip]:
            return False, 429, "IP blocked for 5 minutes due to abuse"
        else:
            del _blocked_ips[ip]
    minute_ago = now - 60
    _request_counts[ip] = [t for t in _request_counts[ip] if t > minute_ago]
    if len(_request_counts[ip]) >= _RATE_LIMIT:
        _blocked_ips[ip] = now + _BLOCK_DURATION
        log_intrusion(ip, 'RATE_LIMIT_BLOCK', f'{len(_request_counts[ip])} reqs/min')
        return False, 429, "Rate limit exceeded — IP blocked for 5 minutes"
    burst_ago = now - 5
    burst = [t for t in _request_counts[ip] if t > burst_ago]
    if len(burst) >= _BURST_LIMIT:
        return False, 429, "Burst limit exceeded"
    _request_counts[ip].append(now)
    return True, 200, "ok"

# ── Replay Attack Prevention ──────────────────────────────
_used_nonces = {}
_NONCE_WINDOW = 300

def check_replay(ts_str, nonce):
    try:
        ts = int(ts_str)
        now_ms = int(_time.time() * 1000)
        if abs(now_ms - ts) > _NONCE_WINDOW * 1000:
            return False, "Request timestamp expired"
        nonce_key = f"{ts}:{nonce}"
        cutoff = now_ms - _NONCE_WINDOW * 1000
        for k in list(_used_nonces.keys()):
            if _used_nonces[k] < cutoff:
                del _used_nonces[k]
        if nonce_key in _used_nonces:
            return False, "Replay attack detected"
        _used_nonces[nonce_key] = now_ms
        return True, "ok"
    except Exception:
        return True, "ok"

# ── Injection Detection ───────────────────────────────────
_INJECT_RE = _re.compile(
    r'<script|javascript:|onerror=|SELECT.{0,20}FROM|DROP.{0,20}TABLE'
    r'|UNION.{0,20}SELECT|/etc/passwd|cmd\.exe|powershell|base64_decode',
    _re.IGNORECASE
)

def scan_injection(data, depth=0):
    if depth > 4: return False
    if isinstance(data, str):
        return bool(_INJECT_RE.search(data))
    elif isinstance(data, dict):
        return any(scan_injection(v, depth+1) for v in list(data.values())[:20])
    elif isinstance(data, list):
        return any(scan_injection(item, depth+1) for item in data[:20])
    return False

# ── Intrusion Log ─────────────────────────────────────────
_intrusion_log = []
def log_intrusion(ip, event, details=''):
    entry = {'ts': _time.strftime('%Y-%m-%dT%H:%M:%S'), 'ip': ip,
             'event': event, 'details': str(details)[:200]}
    _intrusion_log.append(entry)
    if len(_intrusion_log) > 500: _intrusion_log.pop(0)
    print(f"[JLIGHT-SECURITY] {entry['ts']} | {ip} | {event} | {details[:80]}")

# ── Security Response Headers ─────────────────────────────
@app.after_request
def security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['X-JLIGHT-Version'] = 'v5.0'
    return response

# ── Master Security Middleware ────────────────────────────
@app.before_request
def rate_limit():
    ip = request.remote_addr or 'unknown'
    # Rate limit
    ok, code, msg = check_rate_limit(ip)
    if not ok:
        return jsonify({"error": msg}), code
    # Replay check
    ts = request.headers.get('X-JLIGHT-Timestamp', '')
    nonce = request.headers.get('X-JLIGHT-Nonce', '')
    if ts and nonce:
        ok, msg = check_replay(ts, nonce)
        if not ok:
            log_intrusion(ip, 'REPLAY_ATTACK', msg)
            return jsonify({"error": "Request rejected — replay detected"}), 400
    # Injection scan
    if request.is_json:
        try:
            data = request.get_json(silent=True) or {}
            if scan_injection(data):
                log_intrusion(ip, 'INJECTION_BLOCKED', str(data)[:100])
                return jsonify({"error": "Malicious input detected and blocked"}), 400
        except Exception:
            pass
    # Block scanner tools
    ua = request.headers.get('User-Agent', '').lower()
    if any(t in ua for t in ['sqlmap','nikto','nmap','masscan','nessus','burp']):
        log_intrusion(ip, 'SCANNER_BLOCKED', ua[:80])
        return jsonify({"error": "Forbidden"}), 403
    # Block path scanning
    bad_paths = ['/.env','/.git','/wp-admin','/phpmyadmin','/shell','/config.php']
    if any(request.path.startswith(p) for p in bad_paths):
        log_intrusion(ip, 'PATH_SCAN', request.path)
        return jsonify({"error": "Not found"}), 404

app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB max upload


# ─── Database (optional) ─────────────────────────────────────────────────────

try:
    import psycopg2
    from psycopg2.extras import RealDictCursor
    DB_URL = os.environ.get("DATABASE_URL", "")
    DB_AVAILABLE = bool(DB_URL)
except ImportError:
    DB_AVAILABLE = False

def get_db():
    """Get or create database connection for this request."""
    if not DB_AVAILABLE:
        return None
    if "db" not in g:
        try:
            g.db = psycopg2.connect(DB_URL, cursor_factory=RealDictCursor)
        except Exception:
            return None
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        try:
            db.close()
        except Exception:
            pass

def log_audit(action: str, role: str = "", details: dict = None):
    """Write to audit_log table if DB available, otherwise silent."""
    db = get_db()
    if not db:
        return
    try:
        with db.cursor() as cur:
            cur.execute(
                "INSERT INTO audit_log (action, role, details, timestamp) VALUES (%s, %s, %s, %s)",
                (action, role, json.dumps(details or {}), datetime.now(timezone.utc))
            )
        db.commit()
    except Exception:
        pass


# ─── Error Handlers ──────────────────────────────────────────────────────────

@app.errorhandler(400)
def bad_request(e):
    return jsonify({"error": "Bad request", "detail": str(e)}), 400

@app.errorhandler(413)
def too_large(e):
    return jsonify({"error": "File too large", "detail": "Maximum 50MB"}), 413

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Internal server error"}), 500


# ─── Helpers ─────────────────────────────────────────────────────────────────

def success(data: dict, status: int = 200):
    return jsonify({"success": True, **data}), status

def error(message: str, status: int = 400):
    return jsonify({"success": False, "error": message}), status

def get_json_field(data: dict, field: str, required: bool = True):
    val = data.get(field)
    if required and (val is None or val == ""):
        raise ValueError(f"Missing required field: {field}")
    return val


# ─── Health Check ─────────────────────────────────────────────────────────────

# ── Request size guard ──────────────────────────────────────
@app.errorhandler(413)
def too_large(e):
    return jsonify({"error": "File too large. Maximum 50MB."}), 413

def verify_jlight_request():
    """Verify request has JLIGHT signature headers. Warn if missing, never block."""
    timestamp = request.headers.get('X-JLIGHT-Timestamp')
    signature = request.headers.get('X-JLIGHT-Signature')
    role_header = request.headers.get('X-JLIGHT-Role', 'unknown')
    if not timestamp or not signature:
        # Log but do not block — backwards compatible
        app.logger.warning(f"Unsigned JLIGHT request from {request.remote_addr} to {request.path}")
        return False
    # Verify timestamp is within 5 minutes (replay attack prevention)
    try:
        ts = int(timestamp)
        if abs(time.time() * 1000 - ts) > 300000:
            app.logger.warning(f"Stale timestamp from {request.remote_addr}")
            return False
    except (ValueError, TypeError):
        return False
    return True

@app.before_request
def security_checks():
    """Security checks on every request."""
    # Rate limiting already applied
    # Log security-relevant headers
    if request.path not in ['/api/health']:
        verify_jlight_request()

@app.route("/api/health", methods=["GET"])
def health_check():
    db = get_db()
    db_ok = False
    if db:
        try:
            with db.cursor() as cur:
                cur.execute("SELECT 1")
            db_ok = True
        except Exception:
            pass

    return success({
        "status": "healthy",
        "version": "4.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "services": {
            "api": "ok",
            "ml_engine": "ok",
            "bio_engine": "ok",
            "database": "ok" if db_ok else "unavailable (running in stateless mode)",
        }
    })


# ─── CSV Analysis ─────────────────────────────────────────────────────────────

def validate_json_payload(data, required_fields):
    """Validate JSON payload has required fields with correct types."""
    if not isinstance(data, dict):
        return False, "Payload must be a JSON object"
    for field, expected_type in required_fields.items():
        if field in data and not isinstance(data[field], expected_type):
            return False, f"Field '{field}' must be {expected_type.__name__}"
    return True, None

@app.route("/api/analyse-csv", methods=["POST"])
def api_analyse_csv():
    """
    Analyse a CSV/XLSX file for QC anomalies.
    Accepts multipart/form-data (file upload) or JSON with base64 content.
    """
    role = request.headers.get("X-Role", "Laboratory & Research")

    try:
        # Handle file upload
        if request.files.get("file"):
            f = request.files["file"]
            content = f.read()
            filename = f.filename or "upload.csv"

        # Handle JSON with csvText field (from frontend)
        elif request.is_json:
            data = request.get_json()
            csv_text = data.get("csvText", "")
            filename = data.get("fileName", "upload.csv")
            role = data.get("role", role)
            if not csv_text:
                return error("No CSV data provided")
            content = csv_text.encode("utf-8")
        else:
            return error("No file or CSV data provided")

        result = analyse_csv(content, filename, role=role)

        # Log to audit trail
        log_audit("csv_upload", role, {
            "filename": filename,
            "row_count": result.get("rowCount", 0),
            "severity": result.get("severity", "unknown"),
            "risk_score": result.get("riskScore", 0),
        })

        # Save to DB if available
        db = get_db()
        if db and result.get("success"):
            try:
                with db.cursor() as cur:
                    cur.execute(
                        """INSERT INTO csv_uploads
                           (file_name, file_size_kb, row_count, column_count,
                            detected_columns, analysis_result, severity, risk_score)
                           VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                        (
                            filename,
                            round(len(content) / 1024),
                            result.get("rowCount", 0),
                            result.get("columnCount", 0),
                            json.dumps(result.get("detectedColumns", {})),
                            json.dumps({"severity": result.get("severity"), "riskScore": result.get("riskScore")}),
                            result.get("severity", "stable"),
                            result.get("riskScore", 0),
                        )
                    )
                db.commit()
            except Exception:
                pass

        return success(result)

    except ValueError as e:
        return error(str(e))
    except Exception as e:
        app.logger.error(f"CSV analysis error: {traceback.format_exc()}")
        return error(f"Analysis failed: {str(e)}", 500)


# ─── Bioinformatics Endpoints ─────────────────────────────────────────────────

@app.route("/api/bio/tb", methods=["POST"])
def api_tb_resistance():
    """Screen a DNA sequence for TB drug resistance mutations."""
    try:
        data = request.get_json()
        sequence = get_json_field(data, "sequence")

        if len(sequence.replace("\n", "").replace(">", "")) < 50:
            return error("Sequence too short — minimum 50 nucleotides required")

        report = screen_tb_resistance(sequence)

        log_audit("bio_tb_resistance", data.get("role", ""), {
            "seq_length": report.sequence_length,
            "who_category": report.who_category,
            "resistant_count": len(report.resistant_mutations),
        })

        return success({"report": report.to_dict()})

    except ValueError as e:
        return error(str(e))
    except Exception as e:
        app.logger.error(f"TB resistance error: {traceback.format_exc()}")
        return error(str(e), 500)


@app.route("/api/bio/variant", methods=["POST"])
def api_variant():
    """Detect variants between reference and sample sequences."""
    try:
        data = request.get_json()
        ref = get_json_field(data, "reference")
        sample = get_json_field(data, "sample")

        if len(ref.replace("\n", "")) < 10 or len(sample.replace("\n", "")) < 10:
            return error("Sequences too short — minimum 10 nucleotides each")

        report = detect_variants(ref, sample)

        log_audit("bio_variant", data.get("role", ""), {
            "total_variants": report.total_variants,
            "snvs": report.snvs,
            "indels": report.indels,
        })

        return success({"report": report.to_dict()})

    except ValueError as e:
        return error(str(e))
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/bio/ngs", methods=["POST"])
def api_ngs():
    """Compute NGS QC metrics from sequences or file."""
    try:
        sequences = []
        quality_scores = []
        filename = "upload"

        if request.files.get("file"):
            f = request.files["file"]
            filename = f.filename or "reads.fastq"
            records = parse_fasta(f.read())
            sequences = [r["sequence"] for r in records]
            quality_scores = [r["quality"] for r in records if r.get("quality")]

        elif request.is_json:
            data = request.get_json()
            sequences = data.get("sequences", [])
            quality_scores = data.get("quality_scores", [])

        if not sequences:
            sequences = ["ATCGATCGATCG" * 10]  # Demo

        result = analyse_ngs_quality(sequences, quality_scores or None)
        return success({"result": result.to_dict(), "filename": filename})

    except Exception as e:
        return error(str(e), 500)


@app.route("/api/bio/wgs", methods=["POST"])
def api_wgs():
    """Calculate WGS assembly metrics (N50, L50, etc.)."""
    try:
        sequences_or_lengths = []
        filename = "assembly"

        if request.files.get("file"):
            f = request.files["file"]
            filename = f.filename or "assembly.fasta"
            records = parse_fasta(f.read())
            sequences_or_lengths = [r["sequence"] for r in records if r["sequence"]]

        elif request.is_json:
            data = request.get_json()
            sequences_or_lengths = data.get("lengths") or data.get("sequences") or []

        if not sequences_or_lengths:
            return error("No contig sequences or lengths provided")

        result = calculate_wgs_metrics(sequences_or_lengths)
        return success({"result": result.to_dict(), "filename": filename})

    except ValueError as e:
        return error(str(e))
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/bio/sequence", methods=["POST"])
def api_sequence():
    """Full sequence analysis: GC%, ORFs, Tm, MW, reverse complement."""
    try:
        data = request.get_json()
        sequence = get_json_field(data, "sequence")

        result = analyse_sequence(sequence)
        return success({"result": result.to_dict()})

    except ValueError as e:
        return error(str(e))
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/bio/fasta", methods=["POST"])
def api_fasta():
    """Parse a FASTA/FASTQ file and return records."""
    try:
        if not request.files.get("file"):
            return error("No file provided")
        f = request.files["file"]
        records = parse_fasta(f.read())
        return success({
            "record_count": len(records),
            "records": records[:100],  # Cap at 100 records in response
            "filename": f.filename,
        })
    except Exception as e:
        return error(str(e), 500)


# ─── Decision Cards ───────────────────────────────────────────────────────────

@app.route("/api/cards", methods=["GET"])
def api_cards():
    """Return decision cards from DB or static data."""
    role = request.args.get("role", "")
    db = get_db()

    if db:
        try:
            with db.cursor() as cur:
                if role:
                    category = "lab" if "lab" in role.lower() or "laboratory" in role.lower() else \
                               "trial" if "trial" in role.lower() else \
                               "hosp" if "hosp" in role.lower() else ""
                    if category:
                        cur.execute(
                            "SELECT * FROM decision_cards WHERE (category=%s OR category='all') AND status!='archived' ORDER BY created_at DESC",
                            (category,)
                        )
                    else:
                        cur.execute("SELECT * FROM decision_cards WHERE status!='archived' ORDER BY created_at DESC")
                else:
                    cur.execute("SELECT * FROM decision_cards WHERE status!='archived' ORDER BY created_at DESC")
                cards = cur.fetchall()
                return success({"cards": [dict(c) for c in cards], "source": "database"})
        except Exception:
            pass

    return success({"cards": [], "source": "static", "note": "Database unavailable"})


@app.route("/api/cards/acknowledge", methods=["POST"])
def api_acknowledge():
    """Acknowledge a decision card."""
    try:
        data = request.get_json()
        card_number = get_json_field(data, "card_number")
        role = data.get("role", "")

        db = get_db()
        if db:
            with db.cursor() as cur:
                cur.execute(
                    "UPDATE decision_cards SET status='resolved', updated_at=%s WHERE card_number=%s",
                    (datetime.now(timezone.utc), card_number)
                )
            db.commit()

        log_audit("card_acknowledged", role, {
            "card_number": card_number,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        return success({"card_number": card_number, "status": "resolved"})

    except Exception as e:
        return error(str(e), 500)


# ─── Audit Log ────────────────────────────────────────────────────────────────

@app.route("/api/audit", methods=["GET"])
def api_audit():
    """Return recent audit log entries."""
    db = get_db()
    if not db:
        return success({"entries": [], "note": "Database unavailable"})
    try:
        with db.cursor() as cur:
            cur.execute(
                "SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT 100"
            )
            entries = cur.fetchall()
        return success({"entries": [dict(e) for e in entries]})
    except Exception as e:
        return error(str(e), 500)


# ─── Main ─────────────────────────────────────────────────────────────────────

# ─── Connector Endpoints ─────────────────────────────────────────────────────

@app.route("/api/connect/hl7", methods=["POST"])
def api_connect_hl7():
    """Parse an HL7 v2.5 message and run ML analysis."""
    try:
        data = request.get_json()
        raw_hl7 = data.get("message", "")
        if not raw_hl7:
            return error("No HL7 message provided")

        from engine.connectors import HL7Listener
        from engine.ml_engine import JLIGHTMLPipeline

        listener = HL7Listener()
        feed = listener.parse_message(raw_hl7)

        result = {"feed": feed.to_dict()}

        if len(feed.values) >= 3:
            pipeline = JLIGHTMLPipeline()
            ml = pipeline.run(feed.values, feed.timestamps)
            result["ml"] = ml.to_dict()
            result["action_required"] = ml.action_required

        log_audit("hl7_message", data.get("role", ""), {
            "source": feed.metadata.get("sending_facility", ""),
            "observations": feed.record_count,
        })

        return success(result)
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/connect/redcap", methods=["POST"])
def api_connect_redcap():
    """Connect to REDCap and analyse consent timing + SAE patterns."""
    try:
        data = request.get_json()
        url = data.get("url", "")
        token = data.get("token", "")
        if not url or not token:
            return error("REDCap URL and token required")

        from engine.connectors import REDCapConnector
        from engine.ml_engine import JLIGHTMLPipeline

        connector = REDCapConnector(url, token)
        feed = connector.get_records()

        if not feed.connected:
            return error(f"REDCap connection failed: {feed.error}")

        result = {
            "feed": feed.to_dict(),
            "consent_violations": feed.metadata.get("consent_violations", 0),
            "sae_overdue": feed.metadata.get("sae_overdue", 0),
        }

        if len(feed.values) >= 3:
            pipeline = JLIGHTMLPipeline(iso_threshold=24.0)  # 24h consent threshold
            ml = pipeline.run(feed.values, feed.timestamps)
            result["ml"] = ml.to_dict()

        log_audit("redcap_sync", data.get("role", ""), {
            "records": feed.record_count,
            "violations": result["consent_violations"],
        })

        return success(result)
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/connect/islims", methods=["POST"])
def api_connect_islims():
    """Connect to iSkyLIMS and analyse NGS run QC metrics."""
    try:
        data = request.get_json()
        url = data.get("url", "")
        token = data.get("token", "")
        run_id = data.get("run_id")

        if not url:
            return error("iSkyLIMS URL required")

        from engine.connectors import iSkyLIMSConnector
        from engine.ml_engine import JLIGHTMLPipeline

        connector = iSkyLIMSConnector(url, token)
        feed = connector.get_run_stats(run_id)

        if not feed.connected:
            return error(f"iSkyLIMS connection failed: {feed.error}")

        result = {"feed": feed.to_dict()}

        if len(feed.values) >= 3:
            pipeline = JLIGHTMLPipeline(iso_threshold=80.0)  # Q30 must be > 80%
            ml = pipeline.run(feed.values, feed.timestamps)
            result["ml"] = ml.to_dict()

        return success(result)
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/connect/fhir", methods=["POST"])
def api_connect_fhir():
    """Connect to FHIR R4 server and analyse observations."""
    try:
        data = request.get_json()
        url = data.get("url", "")
        token = data.get("token", "")
        resource_type = data.get("resource", "observations")

        if not url:
            return error("FHIR server URL required")

        from engine.connectors import FHIRAdapter
        from engine.ml_engine import JLIGHTMLPipeline

        adapter = FHIRAdapter(url, token)

        if resource_type == "bed_occupancy":
            feed = adapter.get_bed_occupancy()
        else:
            feed = adapter.get_observations(
                code=data.get("code"),
                patient_id=data.get("patient_id"),
            )

        if not feed.connected:
            return error(f"FHIR connection failed: {feed.error}")

        result = {"feed": feed.to_dict()}
        if len(feed.values) >= 3:
            pipeline = JLIGHTMLPipeline()
            ml = pipeline.run(feed.values, feed.timestamps)
            result["ml"] = ml.to_dict()

        return success(result)
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/connect/test", methods=["POST"])
def api_connect_test():
    """Test a connector configuration without pulling full data."""
    try:
        data = request.get_json()
        source = data.get("source", "").lower()
        config = data.get("config", {})

        from engine.connectors import get_connector

        connector = get_connector(source, config)
        connected = False

        if hasattr(connector, "test_connection"):
            connected = connector.test_connection()
        else:
            connected = True  # CSV pipeline always works

        return success({
            "source": source,
            "connected": connected,
            "message": f"{source} connector {'connected' if connected else 'failed'}",
        })
    except Exception as e:
        return error(str(e), 500)




@app.route("/api/connect/tiernet", methods=["POST", "GET"])
def api_connect_tiernet():
    """Connect to TIER.Net SA HIV/TB programme."""
    try:
        data = request.get_json(silent=True) or {}
        url = data.get("url", "")
        token = data.get("token", "")
        if not url:
            return success({
                "status": "not_configured",
                "message": "TIER.Net URL not provided. Contact your facility IT for the TIER.Net API endpoint.",
                "records": 0,
                "connected": False,
                "note": "TIER.Net integration requires formal data sharing agreement with NDoH"
            })
        # Attempt connection
        import urllib.request
        req = urllib.request.Request(f"{url.rstrip('/')}/api/status",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=10)
            return success({"status": "ok", "connected": True, "message": "TIER.Net connected", "records": 0})
        except Exception:
            return success({"status": "unreachable", "connected": False,
                "message": "TIER.Net endpoint unreachable. JLIGHT continues in standalone mode.",
                "records": 0})
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/connect/eimpilo", methods=["POST", "GET"])
def api_connect_eimpilo():
    """Connect to e-Impilo NHI EMR (FHIR R4)."""
    try:
        data = request.get_json(silent=True) or {}
        url = data.get("url", "")
        token = data.get("token", "")
        if not url:
            return success({
                "status": "not_deployed",
                "message": "e-Impilo is being deployed nationally 2025-2029. JLIGHT is NHI-ready and will connect automatically when available.",
                "records": 0,
                "connected": False,
                "fhir_ready": True,
                "hprs_aligned": True,
                "nhi_ready": True
            })
        # Try FHIR metadata endpoint
        import urllib.request
        req = urllib.request.Request(f"{url.rstrip('/')}/metadata",
            headers={"Authorization": f"Bearer {token}", "Accept": "application/fhir+json"})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return success({"status": "ok", "connected": True,
                    "message": "e-Impilo FHIR R4 endpoint connected", "records": 0})
        except Exception:
            return success({"status": "unreachable", "connected": False,
                "message": "e-Impilo endpoint unreachable. JLIGHT continues in standalone mode.",
                "records": 0})
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/alert", methods=["POST"])
def api_alert():
    """Receive and store a JLIGHT alert for notification dispatch."""
    try:
        data = request.get_json(silent=True) or {}
        card_key = data.get("card_key", "")
        severity = data.get("severity", "att")
        title = data.get("title", "JLIGHT Alert")
        role = data.get("role", "")
        message = data.get("message", "")
        
        # Log alert
        alert_record = {
            "card_key": card_key,
            "severity": severity,
            "title": title,
            "role": role,
            "message": message,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        # Store in DB if available
        if DB_AVAILABLE:
            try:
                db = get_db()
                if db:
                    cur = db.cursor()
                    cur.execute(
                        "INSERT INTO alerts (card_id, severity, message, role, created_at) VALUES (%s, %s, %s, %s, %s)",
                        (card_key, severity, title, role, datetime.now(timezone.utc))
                    )
                    db.commit()
            except Exception:
                pass
        
        # Email notification for critical alerts
        if severity == "crit":
            notification_email = os.environ.get("ALERT_EMAIL", "")
            if notification_email:
                try:
                    import smtplib
                    from email.mime.text import MIMEText
                    smtp_host = os.environ.get("SMTP_HOST", "")
                    smtp_user = os.environ.get("SMTP_USER", "")
                    smtp_pass = os.environ.get("SMTP_PASS", "")
                    if smtp_host and smtp_user:
                        msg = MIMEText(f"JLIGHT CRITICAL ALERT\n\nCard: {card_key}\nTitle: {title}\nMessage: {message}\nTime: {alert_record['timestamp']}")
                        msg["Subject"] = f"[JLIGHT CRITICAL] {title}"
                        msg["From"] = smtp_user
                        msg["To"] = notification_email
                        with smtplib.SMTP_SSL(smtp_host, 465) as server:
                            server.login(smtp_user, smtp_pass)
                            server.send_message(msg)
                except Exception:
                    pass  # Email failure never breaks JLIGHT
        
        return success({"received": True, "alert": alert_record})
    except Exception as e:
        return error(str(e), 500)



@app.route("/api/connect/etmf", methods=["POST"])
def api_connect_etmf():
    """Connect to eTMF system — Veeva Vault, Florence, Trial Interactive."""
    try:
        data = request.get_json(silent=True) or {}
        url = data.get("url", "")
        token = data.get("token", "")
        system = data.get("system", "unknown")
        if not url:
            return success({"status": "not_configured", "connected": False,
                "message": "No eTMF URL provided. JLIGHT continues in standalone mode.",
                "records": 0})
        import urllib.request
        # Try eTMF API endpoint
        headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
        if "veevavault" in url.lower():
            headers["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request(url, headers=headers)
        try:
            urllib.request.urlopen(req, timeout=12)
            return success({"status": "ok", "connected": True,
                "message": f"{system} eTMF connected", "records": 0, "system": system})
        except Exception as e:
            return success({"status": "unreachable", "connected": False,
                "message": f"{system} unreachable. JLIGHT continues standalone. {str(e)[:80]}",
                "records": 0})
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/connect/ctms", methods=["POST"])
def api_connect_ctms():
    """Connect to CTMS — Medidata, Veeva Vault CTMS, REDCap."""
    try:
        data = request.get_json(silent=True) or {}
        url = data.get("url", "")
        token = data.get("token", "")
        system = data.get("system", "unknown")
        if not url:
            return success({"status": "not_configured", "connected": False,
                "message": "No CTMS URL provided. JLIGHT continues in standalone mode.",
                "records": 0})
        import urllib.request
        req = urllib.request.Request(url,
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=12)
            return success({"status": "ok", "connected": True,
                "message": f"{system} CTMS connected", "records": 0, "system": system})
        except Exception as e:
            return success({"status": "unreachable", "connected": False,
                "message": f"{system} unreachable. JLIGHT continues standalone.",
                "records": 0})
    except Exception as e:
        return error(str(e), 500)



@app.route("/api/connect/veeva", methods=["POST", "GET"])
def api_connect_veeva():
    """Connect to Veeva Vault eTMF/CTMS — read-only intelligence feed."""
    try:
        data = request.get_json(silent=True) or {}
        url = data.get("url", "").rstrip("/")
        token = data.get("token", "")
        if not url:
            return success({"status": "not_configured", "connected": False,
                "message": "Veeva Vault URL not provided. Requires Veeva API credentials.",
                "records": 0})
        import urllib.request
        req = urllib.request.Request(f"{url}/api/v24.1",
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=10)
            return success({"status": "ok", "connected": True,
                "message": "Veeva Vault connected — reading enrollment and visit data", "records": 0})
        except Exception:
            return success({"status": "unreachable", "connected": False,
                "message": "Veeva Vault unreachable. JLIGHT continues in standalone mode.", "records": 0})
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/connect/medidata", methods=["POST", "GET"])
def api_connect_medidata():
    """Connect to Medidata Rave EDC/CTMS."""
    try:
        data = request.get_json(silent=True) or {}
        url = data.get("url", "").rstrip("/")
        token = data.get("token", "")
        if not url:
            return success({"status": "not_configured", "connected": False,
                "message": "Medidata Rave URL not provided.", "records": 0})
        import urllib.request
        req = urllib.request.Request(f"{url}/RaveWebServices/studies",
            headers={"Authorization": f"Basic {token}", "Accept": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=10)
            return success({"status": "ok", "connected": True,
                "message": "Medidata Rave connected", "records": 0})
        except Exception:
            return success({"status": "unreachable", "connected": False,
                "message": "Medidata Rave unreachable. JLIGHT continues in standalone mode.", "records": 0})
    except Exception as e:
        return error(str(e), 500)


@app.route("/api/connect/openclinica", methods=["POST", "GET"])
def api_connect_openclinica():
    """Connect to OpenClinica EDC — used in SA academic trials."""
    try:
        data = request.get_json(silent=True) or {}
        url = data.get("url", "").rstrip("/")
        token = data.get("token", "")
        if not url:
            return success({"status": "not_configured", "connected": False,
                "message": "OpenClinica URL not provided.", "records": 0})
        import urllib.request
        req = urllib.request.Request(f"{url}/rest2/api/studies",
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=10)
            return success({"status": "ok", "connected": True,
                "message": "OpenClinica connected — SA academic trial data available", "records": 0})
        except Exception:
            return success({"status": "unreachable", "connected": False,
                "message": "OpenClinica unreachable. JLIGHT continues in standalone mode.", "records": 0})
    except Exception as e:
        return error(str(e), 500)



@app.route("/api/security/status", methods=["GET"])
def api_security_status():
    """Security status — intrusion log summary for System Monitor."""
    try:
        return success({
            "intrusion_attempts": len(_intrusion_log),
            "blocked_ips": len(_blocked_ips),
            "recent_events": _intrusion_log[-10:] if _intrusion_log else [],
            "rate_limit": _RATE_LIMIT,
            "burst_limit": _BURST_LIMIT,
            "replay_protection": True,
            "injection_scanning": True,
            "security_headers": True,
            "status": "armed"
        })
    except Exception as e:
        return error(str(e), 500)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_ENV", "production") == "development"
    print(f"\n🧬 JLIGHT API v4.0 starting on port {port}")
    print(f"   Database: {'connected' if DB_AVAILABLE else 'not configured (stateless mode)'}")
    print(f"   Mode: {'development' if debug else 'production'}\n")
    app.run(host="0.0.0.0", port=port, debug=debug)

