// netlify/functions/send-email.js
// Handles all email sending for JLIGHT:
// - Report emails (compliance audit, intelligence reports)
// - Alert notifications (critical cards, SAE alerts)
// - Test emails
//
// Uses Resend (resend.com) - free tier: 3,000 emails/month
// Set RESEND_API_KEY in Netlify environment variables

const ALLOWED_ORIGIN = 'https://jlight-health.co.za'
const FROM_EMAIL = 'JLIGHT <alerts@jlight-health.co.za>'

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders(),
      body: ''
    }
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders(), body: JSON.stringify({ error: 'Method not allowed' }) }
  }

  // Verify origin
  const origin = event.headers.origin || event.headers.Origin || ''
  if (origin && origin !== ALLOWED_ORIGIN && !origin.includes('localhost')) {
    return { statusCode: 403, headers: corsHeaders(), body: JSON.stringify({ error: 'Forbidden' }) }
  }

  const apiKey = process.env.RESEND_API_KEY
  if (!apiKey) {
    return { statusCode: 500, headers: corsHeaders(), body: JSON.stringify({ error: 'Email service not configured. Add RESEND_API_KEY to Netlify environment variables.' }) }
  }

  let body
  try {
    body = JSON.parse(event.body)
  } catch {
    return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: 'Invalid JSON body' }) }
  }

  const { type, to, userName, role, data } = body

  if (!to || !type) {
    return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: 'Missing required fields: to, type' }) }
  }

  // Validate email format
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to)) {
    return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: 'Invalid email address' }) }
  }

  let subject, html

  switch (type) {
    case 'compliance_report':
      subject = `JLIGHT Compliance Audit Report — ${new Date().toLocaleDateString('en-ZA', { day: 'numeric', month: 'long', year: 'numeric' })}`
      html = buildComplianceReportEmail(userName, role, data)
      break
    case 'intelligence_report':
      subject = `JLIGHT Intelligence Report — ${new Date().toLocaleDateString('en-ZA', { day: 'numeric', month: 'long', year: 'numeric' })}`
      html = buildIntelligenceReportEmail(userName, role, data)
      break
    case 'critical_alert':
      subject = `🚨 JLIGHT CRITICAL ALERT — ${data?.cardTitle || 'Action Required'}`
      html = buildCriticalAlertEmail(userName, role, data)
      break
    case 'test':
      subject = 'JLIGHT — Email Test Successful ✅'
      html = buildTestEmail(userName)
      break
    default:
      return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: `Unknown email type: ${type}` }) }
  }

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ from: FROM_EMAIL, to, subject, html })
    })

    const result = await response.json()

    if (!response.ok) {
      console.error('Resend error:', result)
      return { statusCode: 500, headers: corsHeaders(), body: JSON.stringify({ error: result.message || 'Email send failed', details: result }) }
    }

    return { statusCode: 200, headers: corsHeaders(), body: JSON.stringify({ success: true, id: result.id, message: `Email sent to ${to}` }) }

  } catch (err) {
    console.error('Fetch error:', err)
    return { statusCode: 500, headers: corsHeaders(), body: JSON.stringify({ error: 'Network error sending email: ' + err.message }) }
  }
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json'
  }
}

function emailWrapper(content) {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#F4F7FB;color:#0A1628;padding:32px 16px}
    .wrap{max-width:600px;margin:0 auto}
    .header{background:linear-gradient(135deg,#0A1628,#112448);border-radius:16px 16px 0 0;padding:28px 32px;display:flex;align-items:center;gap:14px}
    .gem{width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#00D4C8,#007A72);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:900;color:#0A1628;flex-shrink:0}
    .brand{color:white;font-size:22px;font-weight:800;letter-spacing:-0.5px}
    .tagline{color:rgba(255,255,255,0.45);font-size:11px;letter-spacing:1px;text-transform:uppercase;margin-top:2px}
    .body{background:white;padding:32px;border-left:1px solid #E8EFF8;border-right:1px solid #E8EFF8}
    .footer{background:#F4F7FB;border:1px solid #E8EFF8;border-radius:0 0 16px 16px;padding:18px 32px;font-size:11px;color:#90AACC;text-align:center}
    .section-title{font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#5A7A9E;margin:24px 0 12px;padding-bottom:6px;border-bottom:1px solid #E8EFF8}
    .kpi-row{display:flex;gap:12px;margin-bottom:16px}
    .kpi{flex:1;background:#F4F7FB;border:1px solid #E8EFF8;border-radius:10px;padding:14px;text-align:center}
    .kpi-val{font-size:26px;font-weight:900;letter-spacing:-1px;margin-bottom:3px}
    .kpi-lbl{font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:#90AACC}
    .row{display:flex;align-items:flex-start;gap:12px;padding:10px 14px;border-bottom:1px solid #F4F7FB}
    .row:last-child{border-bottom:none}
    .pill{font-size:10px;font-weight:700;padding:3px 9px;border-radius:20px;white-space:nowrap}
    .pill.breach{background:#FFF0F0;color:#C82020;border:1px solid rgba(200,32,32,.2)}
    .pill.risk{background:#FFFAED;color:#B07000;border:1px solid rgba(176,112,0,.2)}
    .pill.ok{background:#EDFAF4;color:#1A7A48;border:1px solid rgba(26,122,72,.2)}
    .pill.crit{background:#FFF0F0;color:#C82020;border:1px solid rgba(200,32,32,.2)}
    .pill.att{background:#FFFAED;color:#B07000;border:1px solid rgba(176,112,0,.2)}
    .btn{display:inline-block;background:linear-gradient(135deg,#00D4C8,#007A72);color:#0A1628;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:700;font-size:13px;margin-top:20px}
    h2{font-size:20px;font-weight:800;color:#0A1628;margin-bottom:6px;letter-spacing:-0.5px}
    p{font-size:13px;color:#5A7A9E;line-height:1.7;margin-bottom:12px}
  </style></head><body><div class="wrap">
    <div class="header"><div class="gem">J</div><div><div class="brand">JLIGHT</div><div class="tagline">Health Intelligence System v4</div></div></div>
    <div class="body">${content}</div>
    <div class="footer">JLIGHT Health Intelligence · jlight-health.co.za · POPIA-compliant · Data residency: ZA<br>This report was generated automatically. Do not reply to this email.</div>
  </div></body></html>`
}

function buildComplianceReportEmail(userName, role, data) {
  const breaches = data?.breaches || 3
  const atRisk = data?.atRisk || 5
  const compliant = data?.compliant || 18
  const total = data?.total || 26
  const date = new Date().toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })

  const items = data?.items || [
    { s: 'breach', ico: '🔬', t: 'ISO 15189 §5.6.2 — QC CV Limit', d: 'QC CV exceeded 3.0% for 9 consecutive windows on Analyser 2' },
    { s: 'breach', ico: '🧫', t: 'ISO 15189 §5.3.1 — Calibration Interval', d: 'Analyser 3 calibration gap: 9 days (maximum 7 days)' },
    { s: 'breach', ico: '📋', t: 'SANAS R47-01 §6.4 — Reagent Lot Validation', d: 'Lot RG-20260215 loaded without parallel validation' },
    { s: 'risk', ico: '📊', t: 'ISO 15189 §4.9 — Non-conformance Register', d: 'Reagent contamination event not documented within 24 hours' },
    { s: 'risk', ico: '💉', t: 'NCS Domain 7 §7.1 — Infection Control', d: '3 CLABSI cases in Ward F — NICD notification required' },
  ]

  const rows = items.map(item =>
    `<div class="row"><span style="font-size:16px">${item.ico}</span><div style="flex:1"><div style="font-size:13px;font-weight:600;color:#0A1628;margin-bottom:2px">${item.t}</div><div style="font-size:11px;color:#5A7A9E">${item.d}</div></div><span class="pill ${item.s}">${item.s === 'breach' ? 'BREACH' : item.s === 'risk' ? 'AT RISK' : 'OK'}</span></div>`
  ).join('')

  return emailWrapper(`
    <h2>Compliance Audit Report</h2>
    <p>Hi ${userName || 'there'}, here is your JLIGHT compliance audit report for <strong>${date}</strong>. ${breaches > 0 ? `There are <strong style="color:#C82020">${breaches} active breaches</strong> requiring immediate attention.` : 'All systems are compliant.'}</p>
    <div class="kpi-row">
      <div class="kpi"><div class="kpi-val" style="color:#C82020">${breaches}</div><div class="kpi-lbl">Breaches</div></div>
      <div class="kpi"><div class="kpi-val" style="color:#B07000">${atRisk}</div><div class="kpi-lbl">At Risk</div></div>
      <div class="kpi"><div class="kpi-val" style="color:#1A7A48">${compliant}</div><div class="kpi-lbl">Compliant</div></div>
      <div class="kpi"><div class="kpi-val" style="color:#00A89E">${total}</div><div class="kpi-lbl">Total Checks</div></div>
    </div>
    <div class="section-title">Items Requiring Attention</div>
    <div style="border:1px solid #E8EFF8;border-radius:10px;overflow:hidden">${rows}</div>
    <a href="https://jlight-health.co.za" class="btn">View Full Report in JLIGHT →</a>
  `)
}

function buildIntelligenceReportEmail(userName, role, data) {
  const cards = data?.cardsGenerated || 23
  const resolution = data?.resolutionRate || 87
  const tat = data?.avgTAT || 4.2
  const accuracy = data?.accuracy || 94
  const date = new Date().toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })

  const topCards = data?.topCards || [
    { s: 'crit', t: 'Serious Adverse Event — Expedited Report Due', risk: 98 },
    { s: 'crit', t: 'Protocol Deviation Cluster', risk: 95 },
    { s: 'crit', t: 'HAI Cluster — CLABSI', risk: 90 },
    { s: 'att', t: 'Reagent Contamination Suspected', risk: 88 },
    { s: 'att', t: 'Bed Capacity Critical — Ward C', risk: 85 },
  ]

  const rows = topCards.map(c =>
    `<div class="row"><div style="flex:1"><div style="font-size:13px;font-weight:600;color:#0A1628">${c.t}</div></div><span style="font-family:monospace;font-size:11px;color:${c.s === 'crit' ? '#C82020' : '#B07000'};font-weight:700;margin-right:8px">${c.risk}/100</span><span class="pill ${c.s}">${c.s === 'crit' ? 'CRITICAL' : 'ATTENTION'}</span></div>`
  ).join('')

  return emailWrapper(`
    <h2>Intelligence Report</h2>
    <p>Hi ${userName || 'there'}, here is your JLIGHT intelligence summary for <strong>${date}</strong>. Role: <strong>${role || 'Health Professional'}</strong>.</p>
    <div class="kpi-row">
      <div class="kpi"><div class="kpi-val" style="color:#C82020">${cards}</div><div class="kpi-lbl">Cards Generated</div></div>
      <div class="kpi"><div class="kpi-val" style="color:#1A7A48">${resolution}%</div><div class="kpi-lbl">Resolution Rate</div></div>
      <div class="kpi"><div class="kpi-val" style="color:#B07000">${tat}h</div><div class="kpi-lbl">Avg Resolve Time</div></div>
      <div class="kpi"><div class="kpi-val" style="color:#00A89E">${accuracy}%</div><div class="kpi-lbl">Detection Accuracy</div></div>
    </div>
    <div class="section-title">Top Active Decision Cards</div>
    <div style="border:1px solid #E8EFF8;border-radius:10px;overflow:hidden">${rows}</div>
    <a href="https://jlight-health.co.za" class="btn">View All Cards in JLIGHT →</a>
  `)
}

function buildCriticalAlertEmail(userName, role, data) {
  const card = data || {}
  return emailWrapper(`
    <div style="background:#FFF0F0;border:2px solid rgba(200,32,32,.3);border-radius:12px;padding:20px;margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#C82020;margin-bottom:8px">🚨 CRITICAL ALERT — IMMEDIATE ACTION REQUIRED</div>
      <div style="font-size:18px;font-weight:800;color:#0A1628;margin-bottom:6px">${card.cardTitle || 'Critical Issue Detected'}</div>
      <div style="font-size:13px;color:#5A7A9E">${card.setting || 'Health System · JLIGHT Intelligence'}</div>
    </div>
    <p>Hi ${userName || 'there'}, JLIGHT has detected a critical issue requiring your immediate attention.</p>
    <div style="background:#F4F7FB;border:1px solid #E8EFF8;border-radius:10px;padding:16px;margin:16px 0">
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#5A7A9E;margin-bottom:8px">Recommended Action</div>
      <div style="font-size:13px;color:#0A1628;line-height:1.7">${card.action || 'Please log in to JLIGHT immediately to review and acknowledge this card.'}</div>
    </div>
    <div style="display:flex;gap:10px;margin:16px 0">
      <div style="background:#F4F7FB;border:1px solid #E8EFF8;border-radius:8px;padding:10px 14px;flex:1;text-align:center">
        <div style="font-size:20px;font-weight:900;color:#C82020">${card.risk || '—'}/100</div>
        <div style="font-size:10px;font-weight:600;text-transform:uppercase;color:#90AACC">Risk Score</div>
      </div>
      <div style="background:#F4F7FB;border:1px solid #E8EFF8;border-radius:8px;padding:10px 14px;flex:1;text-align:center">
        <div style="font-size:13px;font-weight:700;color:#C82020">CRITICAL</div>
        <div style="font-size:10px;font-weight:600;text-transform:uppercase;color:#90AACC">Severity</div>
      </div>
      <div style="background:#F4F7FB;border:1px solid #E8EFF8;border-radius:8px;padding:10px 14px;flex:1;text-align:center">
        <div style="font-size:13px;font-weight:700;color:#0A1628">${new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' })} SAST</div>
        <div style="font-size:10px;font-weight:600;text-transform:uppercase;color:#90AACC">Detected At</div>
      </div>
    </div>
    <a href="https://jlight-health.co.za" class="btn">Acknowledge in JLIGHT →</a>
  `)
}

function buildTestEmail(userName) {
  return emailWrapper(`
    <h2>Email Test Successful ✅</h2>
    <p>Hi ${userName || 'there'}, your JLIGHT email configuration is working correctly.</p>
    <div style="background:#EDFAF4;border:1.5px solid rgba(26,122,72,.2);border-radius:10px;padding:16px;margin:16px 0">
      <div style="font-size:13px;color:#1A7A48;font-weight:600">✅ Email delivery confirmed</div>
      <div style="font-size:12px;color:#5A7A9E;margin-top:4px">JLIGHT can now send compliance reports, intelligence summaries, and critical alerts to your email address.</div>
    </div>
    <p>The following email types are now active:</p>
    <div style="display:flex;flex-direction:column;gap:8px;margin:12px 0">
      <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:#F4F7FB;border-radius:8px;border:1px solid #E8EFF8"><span>📊</span><span style="font-size:13px;color:#0A1628">Compliance Audit Reports</span></div>
      <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:#F4F7FB;border-radius:8px;border:1px solid #E8EFF8"><span>📈</span><span style="font-size:13px;color:#0A1628">Intelligence Reports</span></div>
      <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:#F4F7FB;border-radius:8px;border:1px solid #E8EFF8"><span>🚨</span><span style="font-size:13px;color:#0A1628">Critical Alert Notifications</span></div>
    </div>
    <a href="https://jlight-health.co.za" class="btn">Go to JLIGHT →</a>
  `)
}
