// netlify/functions/health-check.js
// Returns system health status for JLIGHT System Monitor

const ALLOWED_ORIGIN = 'https://jlight-health.co.za'

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders(), body: '' }
  }

  const startTime = Date.now()

  // Check Supabase connectivity
  let dbStatus = 'unknown', dbLatency = null
  try {
    const t0 = Date.now()
    const res = await fetch(`${process.env.SUPABASE_URL}/rest/v1/`, {
      headers: { 'apikey': process.env.SUPABASE_ANON_KEY, 'Authorization': `Bearer ${process.env.SUPABASE_ANON_KEY}` }
    })
    dbLatency = Date.now() - t0
    dbStatus = res.ok || res.status === 400 ? 'healthy' : 'degraded'
  } catch { dbStatus = 'error' }

  // Check email service
  let emailStatus = process.env.RESEND_API_KEY ? 'configured' : 'not_configured'

  const totalLatency = Date.now() - startTime

  return {
    statusCode: 200,
    headers: corsHeaders(),
    body: JSON.stringify({
      status: dbStatus === 'healthy' ? 'healthy' : 'degraded',
      timestamp: new Date().toISOString(),
      services: {
        database: { status: dbStatus, latency: dbLatency ? `${dbLatency}ms` : null },
        api: { status: 'healthy', latency: `${totalLatency}ms` },
        email: { status: emailStatus },
        functions: { status: 'healthy' }
      },
      version: 'JLIGHT v4'
    })
  }
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  }
}
