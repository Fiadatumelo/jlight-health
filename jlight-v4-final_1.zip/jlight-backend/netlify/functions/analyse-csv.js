// netlify/functions/analyse-csv.js
// Real statistical analysis for JLIGHT uploaded CSV files
// Performs: Z-score, Westgard multi-rules, CV%, trend detection, breach forecasting

const ALLOWED_ORIGIN = 'https://jlight-health.co.za'

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders(), body: '' }
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders(), body: JSON.stringify({ error: 'Method not allowed' }) }
  }

  let body
  try {
    body = JSON.parse(event.body)
  } catch {
    return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: 'Invalid JSON' }) }
  }

  const { csvText, fileName, role } = body
  if (!csvText) {
    return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: 'No CSV data provided' }) }
  }

  try {
    const result = analyseCSV(csvText, fileName, role)
    return { statusCode: 200, headers: corsHeaders(), body: JSON.stringify(result) }
  } catch (err) {
    return { statusCode: 500, headers: corsHeaders(), body: JSON.stringify({ error: 'Analysis failed: ' + err.message }) }
  }
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  }
}

function analyseCSV(csvText, fileName, role) {
  const lines = csvText.trim().split(/\r?\n/)
  if (lines.length < 2) throw new Error('File must have at least a header row and one data row')

  // Parse headers
  const rawHeaders = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, '').toLowerCase())
  const rowCount = lines.length - 1

  // Detect column types
  const colMap = detectColumns(rawHeaders)

  // Parse all rows
  const rows = []
  for (let i = 1; i < lines.length; i++) {
    const cols = parseCSVLine(lines[i])
    if (cols.length < 2) continue
    const row = {}
    rawHeaders.forEach((h, idx) => { row[h] = cols[idx] ? cols[idx].trim().replace(/^"|"$/g, '') : '' })
    rows.push(row)
  }

  // Extract numeric values for analysis
  const cvValues = colMap.cv ? rows.map(r => parseFloat(r[colMap.cv])).filter(v => !isNaN(v)) : []
  const meanValues = colMap.mean ? rows.map(r => parseFloat(r[colMap.mean])).filter(v => !isNaN(v)) : []
  const rerunValues = colMap.rerun ? rows.map(r => parseFloat(r[colMap.rerun])).filter(v => !isNaN(v)) : []

  // Statistical analysis
  const stats = {}
  if (cvValues.length > 0) {
    stats.cv = computeStats(cvValues)
    stats.cv.westgard = runWestgardRules(cvValues, stats.cv.mean, stats.cv.sd)
    stats.cv.anomalies = cvValues.filter(v => Math.abs((v - stats.cv.mean) / stats.cv.sd) > 3).length
    stats.cv.warnings = cvValues.filter(v => Math.abs((v - stats.cv.mean) / stats.cv.sd) > 2).length
    stats.cv.trend = detectTrend(cvValues)
    stats.cv.breachForecast = forecastBreach(cvValues, 3.0)
  }
  if (meanValues.length > 0) {
    stats.mean = computeStats(meanValues)
    stats.mean.trend = detectTrend(meanValues)
  }
  if (rerunValues.length > 0) {
    stats.rerun = computeStats(rerunValues)
    stats.rerun.anomalies = rerunValues.filter(v => v > 5).length
  }

  // Generate decision card if anomalies found
  const severity = determineSeverity(stats, cvValues)
  const riskScore = computeRiskScore(stats, cvValues)
  const decisionCard = generateDecisionCard(severity, riskScore, stats, fileName, role, colMap, rowCount)

  return {
    success: true,
    fileName: fileName || 'uploaded_file.csv',
    rowCount,
    columnCount: rawHeaders.length,
    detectedColumns: colMap,
    headers: rawHeaders,
    stats,
    severity,
    riskScore,
    decisionCard,
    steps: buildAnalysisSteps(rowCount, rawHeaders, stats, severity, riskScore, colMap)
  }
}

function parseCSVLine(line) {
  const result = []
  let current = ''
  let inQuotes = false
  for (let i = 0; i < line.length; i++) {
    if (line[i] === '"') { inQuotes = !inQuotes }
    else if (line[i] === ',' && !inQuotes) { result.push(current); current = '' }
    else { current += line[i] }
  }
  result.push(current)
  return result
}

function detectColumns(headers) {
  const map = {}
  const patterns = {
    cv: [/^cv/i, /coeff.*var/i, /cv%/i, /variation/i],
    mean: [/^mean$/i, /average/i, /qc.*mean/i, /result/i, /value/i],
    rerun: [/rerun/i, /repeat/i, /redo/i],
    timestamp: [/time/i, /date/i, /stamp/i, /ts$/i],
    batch: [/batch/i, /lot/i, /run/i],
    analyser: [/analyser/i, /analyzer/i, /instrument/i, /machine/i],
    analyte: [/analyte/i, /test/i, /assay/i, /parameter/i]
  }
  for (const [colType, pats] of Object.entries(patterns)) {
    for (const header of headers) {
      if (pats.some(p => p.test(header))) { map[colType] = header; break }
    }
  }
  return map
}

function computeStats(values) {
  const n = values.length
  const mean = values.reduce((a, b) => a + b, 0) / n
  const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / n
  const sd = Math.sqrt(variance)
  const sorted = [...values].sort((a, b) => a - b)
  const min = sorted[0]
  const max = sorted[n - 1]
  const median = n % 2 === 0 ? (sorted[n / 2 - 1] + sorted[n / 2]) / 2 : sorted[Math.floor(n / 2)]
  const cv = mean !== 0 ? (sd / mean) * 100 : 0
  // Z-scores for each value
  const zScores = values.map(v => sd !== 0 ? (v - mean) / sd : 0)
  const maxZ = Math.max(...zScores.map(Math.abs))
  return { n, mean: +mean.toFixed(3), sd: +sd.toFixed(3), min: +min.toFixed(3), max: +max.toFixed(3), median: +median.toFixed(3), cv: +cv.toFixed(2), maxZ: +maxZ.toFixed(2), zScores: zScores.map(z => +z.toFixed(2)) }
}

function runWestgardRules(values, mean, sd) {
  const violations = []
  const n = values.length

  // 1₂s: any value beyond ±2SD (warning)
  const rule1_2s = values.filter(v => Math.abs(v - mean) > 2 * sd).length
  if (rule1_2s > 0) violations.push({ rule: '1₂s', description: `${rule1_2s} value(s) beyond ±2SD — Warning`, severity: 'warning' })

  // 1₃s: any value beyond ±3SD (reject)
  const rule1_3s = values.filter(v => Math.abs(v - mean) > 3 * sd).length
  if (rule1_3s > 0) violations.push({ rule: '1₃s', description: `${rule1_3s} value(s) beyond ±3SD — Reject run`, severity: 'reject' })

  // 2₂s: two consecutive values beyond same ±2SD
  for (let i = 0; i < n - 1; i++) {
    if ((values[i] - mean > 2 * sd && values[i + 1] - mean > 2 * sd) ||
        (values[i] - mean < -2 * sd && values[i + 1] - mean < -2 * sd)) {
      violations.push({ rule: '2₂s', description: `2 consecutive values beyond ±2SD at positions ${i + 1}–${i + 2} — Reject`, severity: 'reject' }); break
    }
  }

  // R₄s: range between two consecutive values exceeds 4SD
  for (let i = 0; i < n - 1; i++) {
    if (Math.abs(values[i] - values[i + 1]) > 4 * sd) {
      violations.push({ rule: 'R₄s', description: `Range between consecutive values exceeds 4SD at positions ${i + 1}–${i + 2} — Reject`, severity: 'reject' }); break
    }
  }

  // 4₁s: four consecutive values beyond ±1SD on same side
  for (let i = 0; i < n - 3; i++) {
    const window = values.slice(i, i + 4)
    if (window.every(v => v - mean > sd) || window.every(v => v - mean < -sd)) {
      violations.push({ rule: '4₁s', description: `4 consecutive values beyond ±1SD (systematic shift at position ${i + 1}) — Reject`, severity: 'reject' }); break
    }
  }

  // 10x: ten consecutive values on same side of mean
  for (let i = 0; i < n - 9; i++) {
    const window = values.slice(i, i + 10)
    if (window.every(v => v > mean) || window.every(v => v < mean)) {
      violations.push({ rule: '10ₓ', description: `10 consecutive values on same side of mean (systematic bias at position ${i + 1}) — Reject`, severity: 'reject' }); break
    }
  }

  return {
    violations,
    hasRejections: violations.some(v => v.severity === 'reject'),
    hasWarnings: violations.some(v => v.severity === 'warning'),
    summary: violations.length === 0 ? 'All Westgard rules passed' : `${violations.length} rule(s) violated`
  }
}

function detectTrend(values) {
  if (values.length < 4) return { direction: 'insufficient_data', slope: 0, confidence: 0 }
  // Simple linear regression
  const n = values.length
  const xs = values.map((_, i) => i)
  const sumX = xs.reduce((a, b) => a + b, 0)
  const sumY = values.reduce((a, b) => a + b, 0)
  const sumXY = xs.reduce((a, x, i) => a + x * values[i], 0)
  const sumX2 = xs.reduce((a, x) => a + x * x, 0)
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX)
  const intercept = (sumY - slope * sumX) / n
  // R² for trend confidence
  const predicted = xs.map(x => slope * x + intercept)
  const ssTot = values.reduce((a, v) => a + Math.pow(v - sumY / n, 2), 0)
  const ssRes = values.reduce((a, v, i) => a + Math.pow(v - predicted[i], 2), 0)
  const r2 = ssTot > 0 ? 1 - ssRes / ssTot : 0
  return {
    direction: Math.abs(slope) < 0.01 ? 'stable' : slope > 0 ? 'increasing' : 'decreasing',
    slope: +slope.toFixed(4),
    r2: +r2.toFixed(3),
    confidence: +(r2 * 100).toFixed(1)
  }
}

function forecastBreach(values, threshold) {
  if (values.length < 3) return null
  const trend = detectTrend(values)
  if (trend.direction !== 'increasing' || trend.slope <= 0) return null
  const lastValue = values[values.length - 1]
  if (lastValue >= threshold) return { eta: 'Already breached', hoursUntilBreach: 0 }
  const remainingGap = threshold - lastValue
  // Assume each data point is ~30 minutes
  const stepsUntilBreach = remainingGap / trend.slope
  const hoursUntilBreach = stepsUntilBreach * 0.5
  if (hoursUntilBreach > 48) return { eta: '>48 hours', hoursUntilBreach: '>48' }
  return {
    eta: `~${hoursUntilBreach.toFixed(1)} hours`,
    hoursUntilBreach: +hoursUntilBreach.toFixed(1),
    confidence: trend.confidence
  }
}

function determineSeverity(stats, cvValues) {
  if (!stats.cv) return 'stable'
  const { anomalies = 0, westgard, mean, maxZ } = stats.cv
  if (westgard?.hasRejections || anomalies > 2 || maxZ > 3.5) return 'crit'
  if (westgard?.hasWarnings || anomalies > 0 || maxZ > 2.5) return 'att'
  if (stats.cv.trend?.direction === 'increasing' && stats.cv.trend?.confidence > 70) return 'att'
  return 'stable'
}

function computeRiskScore(stats, cvValues) {
  if (!stats.cv) return 10
  let score = 0
  const { anomalies = 0, westgard, maxZ = 0, trend, breachForecast } = stats.cv
  score += Math.min(anomalies * 15, 40)
  score += Math.min((maxZ - 2) * 10, 25)
  if (westgard?.hasRejections) score += 20
  else if (westgard?.hasWarnings) score += 10
  if (trend?.direction === 'increasing' && trend.confidence > 60) score += 15
  if (breachForecast && breachForecast.hoursUntilBreach !== '>48') score += 10
  return Math.min(Math.max(Math.round(score), 5), 98)
}

function generateDecisionCard(severity, riskScore, stats, fileName, role, colMap, rowCount) {
  const severityLabel = severity === 'crit' ? 'CRITICAL' : severity === 'att' ? 'ATTENTION' : 'STABLE'
  const cv = stats.cv
  const westgardSummary = cv?.westgard?.violations?.map(v => v.rule).join(', ') || 'None'
  const trendInfo = cv?.trend ? `${cv.trend.direction} (slope: ${cv.trend.slope}/interval, R²: ${cv.trend.r2})` : 'N/A'
  const breachInfo = cv?.breachForecast ? `Forecast breach in ${cv.breachForecast.eta}` : 'No breach forecast'

  return {
    id: `LAB-CSV-${Date.now().toString().slice(-6)}`,
    severity,
    severityLabel,
    riskScore,
    title: severity === 'crit' ? 'Critical QC Anomaly Detected in Uploaded Data' :
           severity === 'att' ? 'QC Irregularities Detected in Uploaded Data' :
           'Uploaded Data Within Acceptable Parameters',
    sub: `${fileName || 'Uploaded CSV'} · ${rowCount} rows analysed · ${new Date().toLocaleTimeString('en-ZA')} SAST`,
    setting: `${role ? role.toUpperCase() : 'LABORATORY'} · CSV Upload Analysis`,
    signals: cv ? [
      [`CV Mean: ${cv.mean.toFixed(2)}%`, cv.mean > 3 ? 'r' : cv.mean > 2 ? 'a' : 'g'],
      [`Max Z-Score: ${cv.maxZ.toFixed(1)}σ`, cv.maxZ > 3 ? 'r' : cv.maxZ > 2 ? 'a' : 'g'],
      [`Westgard: ${westgardSummary}`, cv.westgard?.hasRejections ? 'r' : cv.westgard?.hasWarnings ? 'a' : 'g'],
      [`Trend: ${cv.trend?.direction || 'N/A'}`, cv.trend?.direction === 'increasing' ? 'a' : 'g'],
      [`Anomalies: ${cv.anomalies || 0}`, (cv.anomalies || 0) > 0 ? 'r' : 'g']
    ] : [['Insufficient numeric data detected', 'a'], ['Schema mapping required', 'a']],
    interp: cv ?
      `Analysis of ${rowCount} data rows from ${fileName || 'uploaded file'}. CV% mean: ${cv.mean.toFixed(2)}% (baseline 2.2%). Standard deviation: ${cv.sd.toFixed(3)}. Maximum Z-score: ${cv.maxZ.toFixed(2)}σ. Westgard evaluation: ${cv.westgard?.summary || 'N/A'}. Trend analysis: ${trendInfo}. ${breachInfo}.` :
      `File parsed successfully (${rowCount} rows, ${Object.keys(colMap).length} detected columns). Numeric QC columns (CV%, Mean) were not detected in the expected format. Manual column mapping may be required for full statistical analysis.`,
    action: severity === 'crit' ?
      '<strong>Immediately review all flagged QC results.</strong> Suspend patient reporting for affected parameters until QC CV returns below 3.0%. Initiate CAPA per ISO 15189 §4.10.' :
      severity === 'att' ?
      '<strong>Review the flagged QC windows.</strong> Investigate trending parameters and apply corrective action before the next run cycle.' :
      '<strong>No action required.</strong> All detected parameters are within acceptable QC limits. Continue routine monitoring.',
    iso: severity !== 'stable' ? [
      ['ISO 15189 §5.6.2', 'QC CV% outside allowable limits — mandatory review and corrective action required'],
      ['ISO 15189 §4.9', 'Systematic QC failures must be documented as non-conformances'],
    ] : [['ISO 15189 §5.6.2', 'All QC parameters within acceptable limits — no standards violations detected']],
    stats: {
      rowCount,
      cvMean: cv?.mean,
      cvSD: cv?.sd,
      maxZ: cv?.maxZ,
      anomalies: cv?.anomalies || 0,
      westgardViolations: cv?.westgard?.violations?.length || 0,
      trend: cv?.trend?.direction,
      breachForecast: cv?.breachForecast?.eta
    }
  }
}

function buildAnalysisSteps(rowCount, headers, stats, severity, riskScore, colMap) {
  const cv = stats.cv
  const hasCV = !!colMap.cv
  return [
    {
      step: '📥 File received',
      detail: `${rowCount} data rows · ${headers.length} columns detected · File parsed successfully`,
      status: 'done',
      colour: 'teal'
    },
    {
      step: '🔍 Schema detected',
      detail: headers.length > 0
        ? `Columns: ${headers.slice(0, 5).join(', ')}${headers.length > 5 ? `… +${headers.length - 5} more` : ''} · ${Object.keys(colMap).length} JLIGHT-compatible columns mapped`
        : 'No headers detected — raw data mode',
      status: 'done',
      colour: 'teal'
    },
    {
      step: '📐 Baseline computed',
      detail: cv
        ? `CV% baseline: mean ${cv.mean.toFixed(2)}%, SD ${cv.sd.toFixed(3)} · ${cv.n} measurements analysed`
        : rowCount > 6 ? `Statistical baseline computed from ${rowCount} records` : 'Insufficient rows for baseline computation (minimum 7)',
      status: 'done',
      colour: rowCount > 6 ? 'teal' : 'amber'
    },
    {
      step: '🔍 Anomaly detection',
      detail: cv
        ? `Max Z-score: ${cv.maxZ.toFixed(2)}σ · ${cv.anomalies || 0} anomalies · ${cv.warnings || 0} warnings · Westgard: ${cv.westgard?.summary}`
        : 'Z-score analysis complete · No numeric QC columns for Westgard evaluation',
      status: 'done',
      colour: (cv?.anomalies || 0) > 0 ? 'amber' : 'teal'
    },
    {
      step: '🔮 Predictive analysis',
      detail: cv?.breachForecast
        ? `Breach forecast: ${cv.breachForecast.eta} · Trend: ${cv.trend?.direction} · Confidence: ${cv.trend?.confidence}%`
        : cv?.trend
        ? `Trend: ${cv.trend.direction} · Slope: ${cv.trend.slope}/interval · No breach forecast within 48h`
        : 'Trend analysis complete · Insufficient consecutive data for forecasting',
      status: 'done',
      colour: cv?.breachForecast?.hoursUntilBreach !== '>48' && cv?.breachForecast ? 'amber' : 'teal'
    },
    {
      step: '🧠 Reasoning engine',
      detail: severity === 'crit'
        ? 'Root cause: Critical QC failure — reagent instability or instrument malfunction likely · ISO 15189 §5.6.2 breached'
        : severity === 'att'
        ? 'QC irregularities detected — trending outside acceptable range · Preventive action recommended'
        : 'All parameters within acceptable ranges · No root cause investigation required',
      status: 'done',
      colour: severity === 'crit' ? 'red' : severity === 'att' ? 'amber' : 'teal'
    },
    {
      step: '📋 Decision Card generated',
      detail: `Card #LAB-CSV-${Date.now().toString().slice(-6)} · ${severity === 'crit' ? 'CRITICAL' : severity === 'att' ? 'ATTENTION' : 'STABLE'} severity · Risk Score ${riskScore}/100`,
      status: 'done',
      colour: 'green'
    }
  ]
}
