-- JLIGHT v4 — Quick Fix Script
-- Run this in Supabase SQL Editor

-- Step 1: Add missing columns to decision_cards
ALTER TABLE decision_cards ADD COLUMN IF NOT EXISTS created_by UUID REFERENCES auth.users(id);
ALTER TABLE decision_cards ADD COLUMN IF NOT EXISTS risk_score INTEGER DEFAULT 0;
ALTER TABLE decision_cards ADD COLUMN IF NOT EXISTS source TEXT DEFAULT 'system';
ALTER TABLE decision_cards ADD COLUMN IF NOT EXISTS metadata JSONB DEFAULT '{}';
ALTER TABLE decision_cards ADD COLUMN IF NOT EXISTS facility_id TEXT;
ALTER TABLE decision_cards ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Step 2: Add missing columns to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS facility_id TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS facility_name TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Step 3: Add UNIQUE constraint to card_number so seed data works
ALTER TABLE decision_cards DROP CONSTRAINT IF EXISTS decision_cards_card_number_key;
ALTER TABLE decision_cards ADD CONSTRAINT decision_cards_card_number_key UNIQUE (card_number);

-- Step 4: Create missing tables
CREATE TABLE IF NOT EXISTS alerts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  card_id UUID REFERENCES decision_cards(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  type TEXT DEFAULT 'info',
  acknowledged BOOLEAN DEFAULT FALSE,
  acknowledged_by UUID REFERENCES auth.users(id),
  acknowledged_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS csv_uploads (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  file_name TEXT NOT NULL,
  file_size_kb INTEGER,
  row_count INTEGER,
  column_count INTEGER,
  detected_columns JSONB DEFAULT '{}',
  analysis_result JSONB DEFAULT '{}',
  severity TEXT,
  risk_score INTEGER,
  uploaded_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id),
  user_email TEXT,
  action TEXT NOT NULL,
  resource_type TEXT,
  resource_id TEXT,
  details JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS system_health_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  service TEXT NOT NULL,
  status TEXT NOT NULL,
  latency_ms INTEGER,
  details JSONB DEFAULT '{}',
  checked_at TIMESTAMPTZ DEFAULT NOW()
);

-- Step 5: Enable RLS on all tables
ALTER TABLE decision_cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE csv_uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_health_log ENABLE ROW LEVEL SECURITY;

-- Step 6: RLS policies
DROP POLICY IF EXISTS "cards_select_all" ON decision_cards;
DROP POLICY IF EXISTS "cards_insert_own" ON decision_cards;
DROP POLICY IF EXISTS "cards_update_own" ON decision_cards;
CREATE POLICY "cards_select_all" ON decision_cards FOR SELECT TO authenticated USING (true);
CREATE POLICY "cards_insert_own" ON decision_cards FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "cards_update_own" ON decision_cards FOR UPDATE TO authenticated USING (true);

DROP POLICY IF EXISTS "alerts_all" ON alerts;
CREATE POLICY "alerts_all" ON alerts TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "uploads_own" ON csv_uploads;
CREATE POLICY "uploads_own" ON csv_uploads TO authenticated USING (auth.uid() = uploaded_by) WITH CHECK (auth.uid() = uploaded_by);

DROP POLICY IF EXISTS "audit_own" ON audit_log;
CREATE POLICY "audit_own" ON audit_log FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "audit_insert" ON audit_log;
CREATE POLICY "audit_insert" ON audit_log FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "health_all" ON system_health_log;
CREATE POLICY "health_all" ON system_health_log TO authenticated USING (true) WITH CHECK (true);

-- Step 7: Auto-create profile trigger
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'Lab Manager')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Step 8: Seed decision cards
INSERT INTO decision_cards (card_number, title, category, severity, status, risk_score, setting, source)
VALUES
  ('LAB-0047', 'Emerging Batch-Level Instability', 'lab', 'att', 'open', 72, 'LABORATORY · Batch Quality Control', 'system'),
  ('LAB-0055', 'Reagent Contamination Suspected', 'lab', 'crit', 'open', 88, 'LABORATORY · Reagent Management', 'system'),
  ('LAB-0061', 'Critical SOP Deviation Detected', 'lab', 'crit', 'open', 91, 'LABORATORY · SOP Compliance', 'system'),
  ('LAB-0048', 'Systematic Drift — Analyser 3', 'lab', 'att', 'resolved', 65, 'LABORATORY · Instrument Monitoring', 'system'),
  ('LAB-NGS-003', 'NGS QC Failure: High GC Content', 'lab', 'att', 'open', 60, 'LABORATORY · Bioinformatics · NGS QC', 'system'),
  ('TRIAL-0019', 'Protocol Deviation Cluster', 'trial', 'crit', 'open', 95, 'CLINICAL TRIAL · Site Monitoring', 'system'),
  ('TRIAL-0024', 'Serious Adverse Event — Expedited Report Due', 'trial', 'crit', 'open', 98, 'CLINICAL TRIAL · Safety Monitoring', 'system'),
  ('TRIAL-0031', 'Site Risk Score Elevated', 'trial', 'att', 'open', 68, 'CLINICAL TRIAL · Site Risk Assessment', 'system'),
  ('HOSP-0031', 'Cross-Department Bottleneck', 'hosp', 'att', 'open', 70, 'HOSPITAL OPERATIONS · Cross-Department', 'system'),
  ('HOSP-0038', 'Bed Capacity Critical — Ward C', 'hosp', 'crit', 'open', 85, 'HOSPITAL OPERATIONS · Bed Management', 'system'),
  ('HOSP-0048', 'HAI Cluster — CLABSI', 'hosp', 'crit', 'open', 90, 'HOSPITAL OPERATIONS · Infection Control', 'system'),
  ('SYS-0112', 'All Systems Within Baseline', 'all', 'stab', 'open', 5, 'ALL SYSTEMS · Continuous Monitoring', 'system')
ON CONFLICT (card_number) DO NOTHING;

-- Step 9: Indexes
CREATE INDEX IF NOT EXISTS idx_cards_status ON decision_cards(status);
CREATE INDEX IF NOT EXISTS idx_cards_category ON decision_cards(category);
CREATE INDEX IF NOT EXISTS idx_uploads_user ON csv_uploads(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id);

-- Step 10: Verify — shows all tables and column counts
SELECT table_name,
  (SELECT count(*) FROM information_schema.columns
   WHERE table_name = t.table_name AND table_schema = 'public') AS columns
FROM information_schema.tables t
WHERE table_schema = 'public'
ORDER BY table_name;
